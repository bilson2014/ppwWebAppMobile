eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('5 d(){c a=$("#f").7().l(),b=!0;g(""==a||m==a||k 0==a)&&($("#4-3").8("6"),$("#4-3").e("请输入手机号码"),b=!1),b}$().j(5(){2.2()});c 2={2:5(){$("#2-i").o(5(){9(d()){9(!s($("#f").7()))g $("#4-3").8("6"),$("#4-3").e("请输入正确的手机格式"),!1;$("#4-3").t("6"),$("#2-v").r("u",p()+"/2/n/h").h().q()}})}};',32,32,'||order|message|label|function|normal|val|show|if|||var|checkData|text|indent_tele|return|submit|btn|ready|void|trim|null|phone|click|getContextPath|remove|attr|checkMobile|hide|action|form'.split('|'),0,{}))
//function checkData() {
//	var a = $("#indent_tele").val().trim(),
//		b = !0;
//	return ("" == a || null == a || void 0 == a) && ($("#label-message").show("normal"), $("#label-message").text("请输入手机号码"), b = !1), b
//}
//$().ready(function() {
//	order.order()
//});
//var order = {
//	order: function() {
//		$("#order-btn").click(function() {
//			if (checkData()) {
//				if (!checkMobile($("#indent_tele").val())) return $("#label-message").show("normal"), $("#label-message").text("请输入正确的手机格式"), !1;
//				$("#label-message").hide("normal"), $("#order-form").attr("action", getContextPath() + "/order/phone/submit").submit().remove()
//			}
//		})
//	}
//};